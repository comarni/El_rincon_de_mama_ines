from flask import Flask, request, jsonify
from flask_cors import CORS
import stripe
import os

app = Flask(__name__)
CORS(app)

# Tu claves de Stripe
stripe.api_key = 'sk_test_51SyEMJ2MlHWgQOvprv0nTEwgTNQSQNeC1vj5qchs93amHSansMfVMz98jHjHPiNcHG3nJdF2yWkbhV6Lya628id900KeNxVfrV'
YOUR_DOMAIN = 'http://localhost:5000'

@app.route('/crear-sesion-stripe', methods=['POST'])
def crear_sesion_stripe():
    try:
        data = request.json
        items = data.get('items', [])

        # Convertir items al formato de Stripe
        line_items = []
        for item in items:
            line_items.append({
                'price_data': {
                    'currency': 'eur',
                    'product_data': {
                        'name': item['name'],
                        'description': item['description']
                    },
                    'unit_amount': item['amount']
                },
                'quantity': item['quantity']
            })

        # Crear sesión de Stripe Checkout
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=line_items,
            mode='payment',
            success_url=f'{YOUR_DOMAIN}/exito.html',
            cancel_url=f'{YOUR_DOMAIN}/cancelado.html'
        )

        return jsonify({'sessionId': session.id})

    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/webhook', methods=['POST'])
def webhook():
    payload = request.get_data()
    sig_header = request.headers.get('Stripe-Signature')

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, 'whsec_...'  # Tu webhook secret
        )

        if event['type'] == 'checkout.session.completed':
            print('✓ Pago completado:', event['data']['object'])
            # Guardar pedido en base de datos aquí

        return jsonify({'received': True})

    except Exception as e:
        print(f'Webhook error: {e}')
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000)
