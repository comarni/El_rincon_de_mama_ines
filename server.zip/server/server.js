const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_default');

const app = express();
app.use(express.json());
app.use(cors());

// Servir archivos estáticos desde la carpeta src
app.use(express.static(path.join(__dirname, '../src')));

// Variables de verificación
console.log('✓ Servidor iniciado');
console.log('✓ STRIPE_SECRET_KEY cargada:', process.env.STRIPE_SECRET_KEY ? 'SÍ' : 'NO ⚠️');
console.log('✓ STRIPE_PUBLISHABLE_KEY:', process.env.STRIPE_PUBLISHABLE_KEY || 'NO CARGADA ⚠️');

const YOUR_DOMAIN = process.env.DOMAIN || 'http://localhost:3001';
const PORT = process.env.PORT || 3001;

// Endpoint de diagnóstico
app.get('/diagnostico', (req, res) => {
  res.json({
    status: 'OK',
    puerto: PORT,
    dominio: YOUR_DOMAIN,
    stripe_key_loaded: !!process.env.STRIPE_SECRET_KEY,
    stripe_key_length: process.env.STRIPE_SECRET_KEY?.length || 0
  });
});

// Endpoint de configuracion para el frontend
app.get('/config', (req, res) => {
  res.json({
    publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || ''
  });
});

// Ruta para crear sesión de checkout
app.post('/crear-sesion-stripe', async (req, res) => {
  try {
    const { items } = req.body;
    
    console.log('📥 Solicitud recibida:', JSON.stringify(items, null, 2));

    // Convertir items al formato que Stripe espera
    const line_items = items.map(item => ({
      price_data: {
        currency: 'eur',
        product_data: {
          name: item.name
        },
        unit_amount: item.price // precio en céntimos
      },
      quantity: item.quantity
    }));

    console.log('📦 Line items para Stripe:', JSON.stringify(line_items, null, 2));

    // Crear sesión de Stripe Checkout
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: line_items,
      mode: 'payment',
      success_url: `${YOUR_DOMAIN}/exito.html`,
      cancel_url: `${YOUR_DOMAIN}/cancelado.html`
    });

    console.log('✅ Sesión creada:', session.id);
    res.json({ sessionId: session.id });
  } catch (error) {
    console.error('❌ Error Stripe:', error.message);
    console.error('Detalle completo:', error);
    res.status(400).json({ error: error.message });
  }
});

// Ruta para webhook (opcional - para confirmar pagos)
app.post('/webhook', express.raw({type: 'application/json'}), (req, res) => {
  const sig = req.headers['stripe-signature'];
  
  try {
    const event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.WEBHOOK_SECRET || 'whsec_default'
    );

    if (event.type === 'checkout.session.completed') {
      console.log('✓ Pago completado:', event.data.object);
      // Aquí puedes guardar el pedido en base de datos
    }

    res.json({received: true});
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(400).send(`Webhook error: ${error.message}`);
  }
});

// Obtener IP local
const os = require('os');
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return 'localhost';
}

const LOCAL_IP = getLocalIP();

// Iniciar servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🚀 Servidor corriendo en:`);
  console.log(`   Local: http://localhost:${PORT}`);
  console.log(`   Red: http://${LOCAL_IP}:${PORT}`);
  console.log(`📦 Usa la URL de Red para otros dispositivos\n`);
});
